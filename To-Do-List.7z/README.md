# To-Do-List

Todo list project from The Odin Project. This one was kinda rough for me because I didn't know how to work with localStorage before this project. I think I could rewrite the code to be shorter/more readable in some places.

Hardest and the most annoying part was using keys and values as projects storage and task storage. In the end I used 1 key as project and stored all projects as values and I created a new key with every task. 
